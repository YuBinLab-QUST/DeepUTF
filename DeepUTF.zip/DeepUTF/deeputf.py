# -*- coding: utf8 -*-
import torch
import torch.nn as nn
import torch.nn.functional as F
from swin_transformer import SwinTransformer
import numpy as np
import sys




def upsample(x, out_size):
    return F.interpolate(x, size=out_size, mode='linear', align_corners=False)


def conv_module(in_, out_, kernel_size=3, stride=1, bias=False, groups=1):
    padding = kernel_size // 2
    return nn.Sequential(nn.BatchNorm1d(in_),
                         nn.ReLU(inplace=True),
                         nn.Conv1d(in_, out_, kernel_size=kernel_size, stride=stride, padding=padding, bias=bias, groups=groups))

class DeepUTF(nn.Module):
    def __init__(self, motiflen=16):
        super(DeepUTF, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=4, out_channels=128, kernel_size=motiflen)
        self.pool1 = nn.MaxPool1d(kernel_size=4, stride=4)
        self.conv2 = nn.Conv1d(in_channels=128, out_channels=128, kernel_size=5)
        self.pool2 = nn.MaxPool1d(kernel_size=4, stride=4)
        self.conv3 = nn.Conv1d(in_channels=128, out_channels=128, kernel_size=3)
        self.pool3 = nn.MaxPool1d(kernel_size=4, stride=4)
        self.conv5 = nn.Conv1d(in_channels=128, out_channels=128, kernel_size=3)
        self.pool5 = nn.MaxPool1d(kernel_size=4, stride=4)
        self.swin_transformer = SwinTransformer()
        self.lstm = nn.LSTM(60, 30, num_layers=6, bidirectional=True, batch_first=True, dropout=0.2)
        self.GAP = nn.AdaptiveAvgPool1d(1)
        self.de_conv4 = conv_module(128,128, kernel_size=3)
        self.de_conv3 = conv_module(128,128, kernel_size=3)
        self.de_conv2 = conv_module(128,128, kernel_size=3)
        self.de_conv1 = conv_module(128, 1, kernel_size=3)
        self.relu = nn.ELU(alpha=0.1, inplace=True)
        self.dropout = nn.Dropout(p=0.2)
        self.sigmoid = nn.Sigmoid()
        self.weight_init()

    def weight_init(self):
        for layer in self.modules():
            if isinstance(layer, (nn.Conv1d, nn.Linear)):
                nn.init.xavier_uniform_(layer.weight)
                if layer.bias is not None:
                    nn.init.constant_(layer.bias, 0)
            elif isinstance(layer, nn.BatchNorm1d):
                nn.init.constant_(layer.weight, 1)
                nn.init.constant_(layer.bias, 0)

    def forward(self, data):
        b, _, _ = data.size()
        add_en1 = data
        Conv1 = self.conv1(data)
        Conv1 = self.relu(Conv1)
        Maxpool1 = self.pool1(Conv1)
        Maxpool1 = self.dropout(Maxpool1)
        add_en2 =Maxpool1
        Conv2 = self.conv2(Maxpool1)
        Conv2 = self.relu(Conv2)
        Maxpool2= self.pool2(Conv2)
        Maxpool2 = self.dropout(Maxpool2)
        add_en3 = Maxpool2
        Conv3 = self.conv3(Maxpool2)
        Conv3 = self.relu(Conv3)
        Maxpool3= self.pool3(Conv3)
        Maxpool3 = self.dropout(Maxpool3)
        features = Maxpool3.unsqueeze(3)
        features = self.swin_transformer(features)
        prev_channels = features.size(1)
        Conv4 = nn.Conv1d(in_channels=prev_channels, out_channels=128, kernel_size=3).cuda()(features)
        Conv4 = self.relu(Conv4)
        add_en4 = Conv4
        encoder_out = self.GAP(Conv4)
        upsample1 = upsample(encoder_out, add_en4.size()[-1])
        upsample1 = upsample1 + add_en4
        de_conv4 = self.de_conv4(upsample1)
        upsample2= upsample(de_conv4, add_en3.size()[-1])
        out_lstm1,_=self.lstm(upsample2)
        out_lstm2, _ = self.lstm(upsample2)
        out_lstm = out_lstm2 + out_lstm1
        upsample2 = out_lstm + add_en3
        de_conv3 = self.de_conv3(upsample2)
        upsample3 = upsample(de_conv3, add_en2.size()[-1])
        upsample3 = upsample3 + add_en2
        de_conv2 = self.de_conv2(upsample3)
        upsample4 = upsample(de_conv2, add_en1.size()[-1])
        out_dense = self.de_conv1(upsample4)

        return out_dense

