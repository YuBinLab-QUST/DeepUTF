#!/usr/bin/python

import os
import sys
import argparse
import numpy as np
import os.path as osp
from swin_transformer import SwinTransformer
from copy import deepcopy
import torch
from torch.utils.data import DataLoader
from datasets import EPIDataSet
import torch.nn as nn
import torch.nn.functional as F

torch.multiprocessing.set_sharing_strategy('file_system')


def upsample(x, out_size):
    return F.interpolate(x, size=out_size, mode='linear', align_corners=False)


def conv_module(in_, out_, kernel_size=3, stride=1, bias=False, groups=1):
    padding = kernel_size // 2
    return nn.Sequential(nn.BatchNorm1d(in_),
                         nn.ReLU(inplace=True),
                         nn.Conv1d(in_, out_, kernel_size=kernel_size, stride=stride, padding=padding, bias=bias,
                                   groups=groups))


class DeepUTF(nn.Module):
    def __init__(self, motiflen=16):
        super(DeepUTF, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=4, out_channels=128, kernel_size=motiflen)
        self.pool1 = nn.MaxPool1d(kernel_size=4, stride=4)
        self.conv2 = nn.Conv1d(in_channels=128, out_channels=128, kernel_size=5)
        self.pool2 = nn.MaxPool1d(kernel_size=4, stride=4)
        self.conv3 = nn.Conv1d(in_channels=128, out_channels=128, kernel_size=3)
        self.pool3 = nn.MaxPool1d(kernel_size=4, stride=4)
        self.conv5 = nn.Conv1d(in_channels=128, out_channels=128, kernel_size=3)
        self.pool5 = nn.MaxPool1d(kernel_size=4, stride=4)
        self.swin_transformer = SwinTransformer()
        self.lstm = None
        self.GAP = nn.AdaptiveAvgPool1d(1)
        self.de_conv4 = conv_module(128, 128, kernel_size=3)
        self.de_conv3 = conv_module(128, 128, kernel_size=3)
        self.de_conv2 = conv_module(128, 128, kernel_size=3)
        self.de_conv1 = conv_module(128, 1, kernel_size=3)
        self.relu = nn.ELU(alpha=0.1, inplace=True)
        self.dropout = nn.Dropout(p=0.2)
        self.sigmoid = nn.Sigmoid()
        self.weight_init()

    def set_lstm_parameters(self, input_size):
        hidden_size = input_size // 2
        proj_size = hidden_size // 2
        while proj_size >= hidden_size:
            proj_size -= 1
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=6, bidirectional=True, batch_first=True, dropout=0.2)

    def weight_init(self):
        """Initialize the new built layers"""
        for layer in self.modules():
            if isinstance(layer, (nn.Conv1d, nn.Linear)):
                nn.init.xavier_uniform_(layer.weight)
                if layer.bias is not None:
                    nn.init.constant_(layer.bias, 0)
            elif isinstance(layer, nn.BatchNorm1d):
                nn.init.constant_(layer.weight, 1)
                nn.init.constant_(layer.bias, 0)

    def forward(self, data):
        """Construct a new computation graph at each froward"""
        b, _, _ = data.size()
        add_en1 = data
        Conv1 = self.conv1(data)
        score = Conv1
        Conv1 = self.relu(Conv1)
        Maxpool1 = self.pool1(Conv1)
        Maxpool1 = self.dropout(Maxpool1)
        add_en2 = Maxpool1
        Conv2 = self.conv2(Maxpool1)
        Conv2 = self.relu(Conv2)
        Maxpool2 = self.pool2(Conv2)
        Maxpool2 = self.dropout(Maxpool2)
        add_en3 = Maxpool2
        Conv3 = self.conv3(Maxpool2)
        Conv3 = self.relu(Conv3)
        Maxpool3 = self.pool3(Conv3)
        Maxpool3 = self.dropout(Maxpool3)
        features = Maxpool3.unsqueeze(3)
        features = self.swin_transformer(features)
        prev_channels = features.size(1)
        Conv4 = nn.Conv1d(in_channels=prev_channels, out_channels=128, kernel_size=3).cuda()(features)  # 500 128 190
        Conv4 = self.relu(Conv4)
        add_en4 = Conv4
        encoder_out = self.GAP(Conv4)
        upsample1 = upsample(encoder_out, add_en4.size()[-1])
        upsample1 = upsample1 + add_en4
        de_conv4 = self.de_conv4(upsample1)
        upsample2 = upsample(de_conv4, add_en3.size()[-1])
        input_size = upsample2.size(2)
        if self.lstm is None or self.lstm.input_size != input_size:
            self.set_lstm_parameters(input_size)
        self.lstm = self.lstm.to(data.device)
        out_lstm3, _ = self.lstm(upsample2)
        out_lstm4, _ = self.lstm(upsample2)
        out_lstm5 = out_lstm4 + out_lstm3
        upsample2 = out_lstm5 + add_en3
        de_conv3 = self.de_conv3(upsample2)
        upsample3 = upsample(de_conv3, add_en2.size()[-1])
        upsample3 = upsample3 + add_en2
        de_conv2 = self.de_conv2(upsample3)
        upsample4 = upsample(de_conv2, add_en1.size()[-1])
        out_dense = self.de_conv1(upsample4)
        return out_dense[0], score[0]


def extract(signal, thres):
    start = end = 0
    seqLen = len(signal)
    position = np.argmax(signal)
    Max = np.max(signal)
    if Max > thres:
        start = position - WINDOW // 2
        end = position + WINDOW // 2
        if start < 0: start = 0
        if end > seqLen - 1:
            end = seqLen - 1
            start = end - WINDOW
    return int(start), int(end)


def motif_all(device, model, state_dict, test_loader, outdir, thres):
    state_dict.pop("lstm.weight_ih_l0", None)
    state_dict.pop("lstm.weight_hh_l0", None)
    model.load_state_dict(state_dict, strict=False)
    model.to(device)
    model.eval()
    motif_data = [0.] * kernel_num
    for i_batch, sample_batch in enumerate(test_loader):
        X_data = sample_batch["data"].float().to(device)
        with torch.no_grad():
            signal_p, score_p = model(X_data)
        signal_p = signal_p.view(-1).data.cpu().numpy()
        start, end = extract(signal_p, thres)
        if start == end: continue
        data = X_data[0].data.cpu().numpy()
        score_p = score_p.data.cpu().numpy()
        score_p = score_p[:, start:end]
        max_index = np.argmax(score_p, axis=1)
        for i in range(kernel_num):
            index = max_index[i]
            index += start
            data_slice = data[:, index:(index + motifLen)]
            motif_data[i] += data_slice
    pfms = pfm_calculate(motif_data, k=kernel_num)
    writeFile(pfms, 'motif', outdir)


def pfm_calculate(motifs, k):
    pfms = []
    informations = []
    for motif in motifs:
        if np.sum(motif) == 0.: continue
        sum_ = np.sum(motif, axis=0)
        if sum_[0] < 10: continue
        pfm = motif / sum_
        pfms.append(pfm)
        row, col = pfm.shape
        information = 0
        for j in range(col):
            information += 2 + np.sum(pfm[:, j] * np.log2(pfm[:, j] + 1e-8))
        informations.append(information)
    pfms_filter = []
    index = np.argsort(np.array(informations))
    index = index[::-1]
    for i in range(len(informations)):
        index_c = index[i]
        pfms_filter.append(pfms[index_c])
    return pfms_filter


def writeFile(pfm, flag, outdir):
    out_f = open(outdir + '/{}.meme'.format(flag), 'w')
    out_f.write("MEME version 5.3.3\n\n")
    out_f.write("ALPHABET= ACGT\n\n")
    out_f.write("strands: + -\n\n")
    out_f.write("Background letter frequencies\n")
    out_f.write("A 0.25 C 0.25 G 0.25 T 0.25\n\n")
    for i in range(len(pfm)):
        out_f.write("MOTIF " + "{}\n".format(i + 1))
        out_f.write("letter-probability matrix: alength= 4 w= {} nsites= {}\n".format(motifLen, motifLen))
        current_pfm = pfm[i]
        for col in range(current_pfm.shape[1]):
            for row in range(current_pfm.shape[0]):
                out_f.write("{:.4f} ".format(current_pfm[row, col]))
            out_f.write("\n")
        out_f.write("\n")
    out_f.close()


def get_args():
    parser = argparse.ArgumentParser(description="DeepUTF for motif prediction")
    parser.add_argument("-d", dest="data_dir", type=str, default=None,
                        help="A directory containing the training data.")
    parser.add_argument("-n", dest="name", type=str, default=None,
                        help="specified data name")
    parser.add_argument("-t", dest="thres", type=float, default=0.3,
                        help="threshold value.")
    parser.add_argument("-g", dest="gpu", type=str, default='0',
                        help="choose gpu device.")
    parser.add_argument("-c", dest="checkpoint", type=str, default='./models/',
                        help="Model snapshot location")
    parser.add_argument("-o", dest="outdir", type=str, default='./motifs/',
                        help="Location of results")
    return parser.parse_args()


args = get_args()
motifLen = 16
WINDOW = 100
kernel_num = 64


def main():
    if torch.cuda.is_available():
        if len(args.gpu.split(',')) == 1:
            device = torch.device("cuda:" + args.gpu)
        else:
            device = torch.device("cuda:" + args.gpu.split(',')[0])
    else:
        device = torch.device("cpu")
    Data = np.load(osp.join(args.data_dir, '%s_test.npz' % args.name))
    seqs, signals = Data['data'], Data['signal']
    data_te = seqs
    signals_te = signals
    test_data = EPIDataSet(data_te, signals_te)
    test_loader = DataLoader(test_data, batch_size=1, shuffle=False, num_workers=0)
    checkpoint_file = osp.join(args.checkpoint, 'model_best.pth')
    chk = torch.load(checkpoint_file)
    state_dict = chk['model_state_dict']
    model = DeepUTF(motiflen=motifLen)
    motif_all(device, model, state_dict, test_loader, args.outdir, args.thres)


if __name__ == "__main__":
    main()

